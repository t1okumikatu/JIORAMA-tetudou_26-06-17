//Broad_Train-1 (超即応・遅延モニター表示・完全安全版)
#include <esp_now.h>
#include <WiFi.h>

const int adcPin = 34;
const int R1 = 5100;
const int R2 = 2000;

/* 使うピンの定義 */
const int IN1 = 23;
const int IN2 = 22;

const int LEDC_TIMER_BIT = 9;   // PWMの範囲 (10bit相当、0〜512)
const int LEDC_BASE_FREQ = 100;  // 周波数(Hz)
const int VALUE_MAX = 512;      // PWMの最大値

// 💡 走行のスムーズ管理変数
volatile uint32_t targetSpeed = 0; 
float currentSpeed = 0.0;          

// ⏱️ 列車1用・遅延計測変数
unsigned long stopSignalReceivedTime = 0;
bool isMeasuringStop = false;
float lastMeasuredDelay = 0.0; // モニター送信用の遅延記録

// 🔥 loop側へ安全に送信指示を出すフラグ
bool readyToSendDelay = false;

// ==========================================================
// 🎯 送受信共通の24バイト統合構造体
// ==========================================================
struct __attribute__((packed)) CombinedPayload {
  uint8_t header;       // data[0]  (99)
  uint8_t train1_speed; // data[1]  ← 列車1自身の速度指示！
  uint8_t fb_light3;    // data[2]
  uint8_t train2_speed; // data[3]
  uint8_t fb_light4;    // data[4]
  uint8_t train3_speed; // data[5]
  uint8_t data5_light;  // data[6]
  uint8_t train4_speed; // data[7]
  uint8_t data6_light;  // data[8]
  uint8_t train1_poji;  // data[9]
  uint8_t train2_poji;  // data[10]
  uint8_t train3_poji;  // data[11]
  uint8_t train4_poji;  // data[12]
  uint8_t Data5_SIn;    // data[13]
  uint8_t Data6_SOut;   // data[14]
  uint8_t Data7_Sub;    // data[15]
  uint8_t Data8_Main;   // data[16]
  uint8_t ctr;          // data[17]
  uint8_t startbutton;  // data[18]
  uint8_t data88;       // data[19]  (88)
  
  float voltage;        // 💡 列車1の「遅延ミリ秒結果」をここに載せてステーションへ送り返す！
};

CombinedPayload recvData; 
CombinedPayload sendData; // 送信用箱
esp_now_peer_info_t slave;

// 💡 モーター制御関数（前方への書き込み）
void forward(uint32_t pwm) {
  if (pwm > VALUE_MAX) pwm = VALUE_MAX;
  ledcWrite(IN1, pwm);
  ledcWrite(IN2, 0);
}

// === 🎯 最速電波受信コールバック ===
void OnDataRecv(const esp_now_recv_info *info, const uint8_t *incomingData, int len) {
  if (len >= sizeof(CombinedPayload)) {
    // 💡 割り込みではなく、ここですぐにローカル展開
    CombinedPayload temp;
    memcpy(&temp, incomingData, sizeof(CombinedPayload));
    
    if (temp.header == 99 && temp.data88 == 88) {
      
      // ⏱️ 走行中(targetSpeed > 0)に、新しく「速度0（停止指示）」が届いた瞬間を検知
      if (targetSpeed > 0 && temp.train1_speed == 0) {
        stopSignalReceivedTime = millis(); // 受信した「その瞬間」の時間を記録
        isMeasuringStop = true;            // 計測フラグON
        
        // 🔥【超即応停止】スムーズフィルターの計算（loop）を待たずに、
        // この電波が届いた100万分の1秒の瞬間に、モーターへ完全停止を叩き込みます！
        currentSpeed = 0.0;
        ledcWrite(IN1, VALUE_MAX); // 強力ショートブレーキ
        ledcWrite(IN2, VALUE_MAX);
        
        // ⏱️ ブレーキをかけた直後にタイムラグを計算
        stopSignalReceivedTime = millis() - stopSignalReceivedTime;
        lastMeasuredDelay = (float)stopSignalReceivedTime;
        isMeasuringStop = false;
        readyToSendDelay = true; // loop側へ「モニターに送れ」と合図
      }

      // 速度データを本番用の変数に反映
      targetSpeed = temp.train1_speed;
      recvData = temp;
    }
  }
}

void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {}

void setup() {
  Serial.begin(115200);
  pinMode(IN1, OUTPUT); 
  pinMode(IN2, OUTPUT); 

  ledcAttach(IN1, LEDC_BASE_FREQ, LEDC_TIMER_BIT);
  ledcAttach(IN2, LEDC_BASE_FREQ, LEDC_TIMER_BIT);
  
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  if (esp_now_init() != ESP_OK) {
    return;
  }
  
  // ブロードキャスト設定
  memset(&slave, 0, sizeof(slave));
  for (int i = 0; i < 6; ++i) {
    slave.peer_addr[i] = (uint8_t)0xff;
  }
  esp_now_add_peer(&slave);
  
  esp_now_register_recv_cb(OnDataRecv);
  esp_now_register_send_cb(OnDataSent);
  
  Serial.println("--- 列車1：最速即応・遅延モニター送信版 起動完了 ---");
}

void loop() {
  // ⏱️ 停止電波を最速処理したあと、ここで安全にモニターへ送信
  if (readyToSendDelay) {
    readyToSendDelay = false; // フラグクリア
    
    Serial.print("【💡 列車1】停止電波受信からブレーキ反映までの実測時間: ");
    Serial.print(lastMeasuredDelay, 0);
    Serial.println(" ms (ミリ秒)");
    
    // Train5 Monitorの「列車2の電圧(Voltage)」欄に擬似表示させるためのデータ詰め込み
    sendData.header = 99;
    sendData.data88 = 88;
    sendData.voltage = lastMeasuredDelay; 
    
    // 安全なメイン処理(loop)からステーションへ一発送信
    esp_now_send(slave.peer_addr, (uint8_t *)&sendData, sizeof(sendData));
  }

  // 💡 【ガクガク抹殺フィルター処理】通常走行時のみ動作
  if (targetSpeed > 0) {
    currentSpeed += ((float)targetSpeed - currentSpeed) * 0.25;
    forward((uint32_t)(currentSpeed + 0.5));
  }
  
  delay(20); 
}